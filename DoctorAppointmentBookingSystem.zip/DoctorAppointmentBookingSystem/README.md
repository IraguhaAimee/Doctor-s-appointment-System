#This website was created as my college project for Database Management System Subject during MCA 1st Semester.

Doctor Appointment booking system created using Html, css, javascript, php and sql.

#To Login as Admin:
Username : admin
password : admin

#To Login as Patient:
email:chandu@gmail.com
password:chandu123

#To Login as Docotr:
username:Prateek
password:prateek123

-create patient account from index page
-create doctor account from admin page
